"""A video playlist class."""


class Playlist:
    """A class used to represent a Playlist."""
