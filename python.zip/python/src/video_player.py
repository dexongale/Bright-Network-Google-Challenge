"""A video player class."""

from random import*
from .video_library import VideoLibrary
import re


class VideoPlayer:
    """A class used to represent a Video Player."""

    def __init__(self):
        self._video_library = VideoLibrary()
        self.playing=False
        self.video="NONE"
        self.pause=False
        self.playlists={}

    def number_of_videos(self):
        num_videos = len(self._video_library.get_all_videos())
        print(f"{num_videos} videos in the library")

    def show_all_videos(self):
        """Returns all videos."""
        print("Here's a list of all available videos:")
       
        videos = self._video_library.get_all_videos()

        for i in range (len(videos)):
            print(videos[i].title, '(',videos[i].video_id,')', videos[i].tags)


        

    def play_video(self, video_id):
        """Plays the respective video.

        Args:
            video_id: The video_id to be played.
        """
        vid=0
        oldVid=0
        videos = self._video_library.get_all_videos()
        for i in range(len(videos)):
            
            if videos[i].video_id==video_id:
                # oldVid=i
                vid=i
                if self.playing==False:
                    print("Playing video:",videos[vid].title)
                    oldVid=vid
                    self.playing=True
                    self.video=videos[vid].title
                    self.pause=False
                else:
                    print("Stopping video:",videos[oldVid].title)
                    print("Playing video:",videos[vid].title)
                break

        if videos[i].video_id!=video_id:
            print("Cannot play video: Video does not exist")


        




    def stop_video(self):
        """Stops the current video."""

        if self.playing==True:
            print("Stopping video:",self.video)
            self.playing=False
        else:
            print("Cannot stop video: No video is currently playing")

        # print("stop_video needs implementation")

    def play_random_video(self):
        """Plays a random video from the video library."""
        oldVid=0
        videos = self._video_library.get_all_videos()
        num=randint(0,4)
        if self.playing==False:
            print("Playing video:",videos[num].title)
            oldVid=num
            self.playing=True
            self.pause=False
            self.video=videos[num].title
        else:
            num=randint(0,4)
            print("Stopping video:",self.video)
            print("Playing video:",videos[num].title)

        # print("play_random_video needs implementation")

    def pause_video(self):
        """Pauses the current video."""
        if (self.playing==True and self.pause==False):
            print("Pausing video:",self.video)
            self.pause=True

            
        if (self.playing==True and self.pause==True):
            print("Video already paused: ",self.video)
        else:
            print("Cannot pause video: No video is currently playing")

        # print("pause_video needs implementation")

    def continue_video(self):
        """Resumes playing the current video."""
        if (self.playing==True and self.pause==False):
            print("Cannot continue video: Video is not paused")
            

            
        if (self.playing==True and self.pause==True):
            print("Continuing video:",self.video)
            self.pause=False
        
        else:
            print("Cannot continue video: No video is currently playing")
        # print("continue_video needs implementation")

    def show_playing(self):
        """Displays video currently playing."""
        if self.playing==False:
            print("No video is currently playing")
        else:
            print("Currently playing:",self.video)

        # print("show_playing needs implementation")

    def create_playlist(self, playlist_name):
        """Creates a playlist with a given name.

        Args:
            playlist_name: The playlist name.
        """
        
        if playlist_name.lower() in self.playlists:
            print('Cannot create playlist: A playlist with the same name already exists')

        else:
            self.playlists[playlist_name.lower()]=[]
            print("Successfully created new playlist:", playlist_name) 

        # print("create_playlist needs implementation")

    def add_to_playlist(self, playlist_name, video_id):
        """Adds a video to a playlist with a given name.

        Args:
            playlist_name: The playlist name.
            video_id: The video_id to be added.
        """
        # print("add_to_playlist needs implementation")
        vid=0
        if playlist_name.lower() in self.playlists:
            videos = self._video_library.get_all_videos()
            for i in range(len(videos)):
                if videos[i].video_id==video_id:
                    vid=i
                    if videos[vid].title not in playlist_name.lower():
                        
                        self.playlists[playlist_name.lower()] += [videos[vid].title]
                    else:
                        print("Cannot add video to my_PLAYlist: Video already added")
            print("Added video to my_playlist:",videos[vid].title)
        else:
            print('Cannot add video to another_playlist: Playlist does not exist')

    def show_all_playlists(self):
        """Display all playlists."""
        if len(self.playlists)==0:
            print("No playlists exist yet")
        else:
            for i in self.playlists.keys():
                print(i)

        # print("show_all_playlists needs implementation")

    def show_playlist(self, playlist_name):
        """Display all videos in a playlist with a given name.

        
        Args:
            playlist_name: The playlist name.
        """
        # print("show_playlist needs implementation")
        if (playlist_name.lower() in self.playlists and len(playlist_name.lower())!=0):
            print(self.playlists[playlist_name.lower()])
        elif (playlist_name.lower() in self.playlists and len(playlist_name.lower())==0):
            print('Showing playlist:',playlist_name)
            print("No videos here yet")
        else:
            print('Cannot show playlist another_playlist: Playlist does not exist')

    def remove_from_playlist(self, playlist_name, video_id):
        """Removes a video to a playlist with a given name.

        Args:
            playlist_name: The playlist name.
            video_id: The video_id to be removed.
        """
        # print("remove_from_playlist needs implementation")

        videos = self._video_library.get_all_videos()
        if (playlist_name.lower() in self.playlists):
            for i in range(len(videos)):
                if videos[i].video_id==video_id:
                    vid=i
                    if videos[vid].title in playlist_name.lower():
                        playlist_name.lower().remove(videos[vid].title)
                        print('Removed video from my_playLIST:',videos[vid].title)
                    else:
                        print('Cannot remove video from my_playlist: Video is not in playlist')
        else:
            print('Cannot remove video from another_playlist: Playlist does not exist')

    def clear_playlist(self, playlist_name):
        """Removes all videos from a playlist with a given name.

        Args:
            playlist_name: The playlist name.
        """
        # print("clears_playlist needs implementation")
        if (playlist_name.lower() in self.playlists):
            for playlist_name in self.playlists:
                self.playlists[playlist_name.lower()].clear()
                print('Successfully removed all videos from my_playlist')
        else:
            print('Cannot clear playlist another_playlist: Playlist does not exist')

    def delete_playlist(self, playlist_name):
        """Deletes a playlist with a given name.

        Args:
            playlist_name: The playlist name.
        """
        # print("deletes_playlist needs implementation")
        if (playlist_name.lower() in self.playlists):
            del self.playlists[playlist_name]
            print('Deleted playlist:',playlist_name)
        else:
            print('Cannot delete playlist my_playlist: Playlist does not exist')


    def search_videos(self, search_term):
        """Display all the videos whose titles contain the search_term.

        Args:
            search_term: The query to be used in search.
        """
        # print("search_videos needs implementation")
        # import re
        ind=[]
        videos = self._video_library.get_all_videos()
        for i in range(len(videos)):
            # print('Looking for "%s" in "%s" ->' % (search_term, videos[i].title), end=' ')
            if re.search(search_term.lower(), videos[i].title.lower()):
                print(i,')',videos[i].title,videos[i].video_id,videos[i].tags)
                ind.append(i)
               

            elif re.search(search_term.lower(), videos[i].title.lower())==False: 
                return('No search results for',search_term)
        ch=int(input("Would you like to play any of the above? If yes, specify the number of the video. \nIf your answer is not a valid number, we will assume it's a no."))
        if ch in ind:
            play=self.play_video(videos[ch].video_id)
            print(play)
        else:
            print("Nope!")

    def search_videos_tag(self, video_tag):
        """Display all videos whose tags contains the provided tag.

        Args:
            video_tag: The video tag to be used in search.
        """
        # print("search_videos_tag needs implementation")
        # ind=[]
        # videos = self._video_library.get_all_videos()
        # for i in range(len(videos)):
            
        #     if re.search(video_tag, videos[i].tags):
        #         print(i,')',videos[i].title,videos[i].video_id,videos[i].tags)
        #         ind.append(i)
               

        #     elif re.search(video_tag, videos[i].tags)==False: 
        #         return('No search results for',video_tag)
        # ch=int(input("Would you like to play any of the above? If yes, specify the number of the video. \nIf your answer is not a valid number, we will assume it's a no."))
        # if ch in ind:
        #     play=self.play_video(videos[ch].video_id)
        #     print(play)
        # else:
        #     print("Nope!")

        

    def flag_video(self, video_id, flag_reason="Not Supplied"):
        """Mark a video as flagged.

        Args:
            video_id: The video_id to be flagged.
            flag_reason: Reason for flagging the video.
        """
        # print("flag_video needs implementation")
        flagged=[]
        videos = self._video_library.get_all_videos()
        for i in range(len(videos)):
            if videos[i].video_id==video_id and videos[i].title not in flagged:
                flagged.append(videos[i].title)
                print('Successfully flagged video:', videos[i].title, '(reason:',flag_reason,')')
            elif videos[i].video_id==video_id and videos[i].title in flagged:
                print('Cannot flag video: Video is already flagged')


    def allow_video(self, video_id):
        """Removes a flag from a video.

        Args:
            video_id: The video_id to be allowed again.
        """
        videos = self._video_library.get_all_videos()
        for i in range(len(videos)):
            if videos[i].video_id==video_id and videos[i].title not in flagged:
                flagged.append(videos[i].title)
                print('Cannot remove flag from video: Video is not flagged')
            elif videos[i].video_id==video_id and videos[i].title in flagged:
                print('Successfully removed flag from video:', videos[i].title)

        # print("allow_video needs implementation")
